# Skin Titan M O D - for L E I A
Latest Version of the mod

## Installation instructions:
>
>      1. search for the green button "clone or download" click it -> download zip
>      2. In Kodi, go to Settings --> AddOns --> Install from zip -> choose the source where you saved the .zip
>      2. Select skin.titan.leiabeta.zip and hit install


## Modded version from Marcelveldts Beta repository

FORUM:	http://forum.kodi.tv/forumdisplay.php?fid=212 (MAIN)
		https://forum.kodi.tv/showthread.php?tid=330749 (MOD THREAD)
