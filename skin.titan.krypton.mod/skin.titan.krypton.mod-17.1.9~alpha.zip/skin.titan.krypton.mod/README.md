# Skin Titan M O D - for K R Y P T O N
This skin is modded.And not avilable in official Repo

## Installation instructions:
>     
>      1. search for the green button "clone or download" click it -> download zip
>      2. In Kodi, go to Settings --> AddOns --> Install from zip -> choose the source where you saved the .zip
>      3. Select **skin.titan.krypton.mod** and hit install


## Modded version from Marcelveldts Beta repository

FORUM:	http://forum.kodi.tv/forumdisplay.php?fid=212 (MAIN)
		https://forum.kodi.tv/showthread.php?tid=330749 (MOD THREAD)
